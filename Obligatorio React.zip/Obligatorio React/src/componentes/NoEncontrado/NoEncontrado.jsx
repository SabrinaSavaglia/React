import { Link } from "react-router"
const NoEncontrado = () => {
    return (
        <div>
            <h1>NoEncontrado</h1>
            <Link to="/">Volver al Inicio</Link>
        </div>
    )
}

export default NoEncontrado