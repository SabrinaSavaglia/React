import React from 'react'

const TituloEvaluaciones = () => {
  return (
    <div className="card-header">Evaluaciones</div>
  )
}

export default TituloEvaluaciones