import React from 'react'

const TituloBuscarUsuariosPorPais = () => {
  return (
    <div className="card-header">Usuarios Por Pais</div>
  )
}

export default TituloBuscarUsuariosPorPais