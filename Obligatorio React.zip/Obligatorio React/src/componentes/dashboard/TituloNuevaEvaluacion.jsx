import React from "react";

const TituloNuevaEvaluacion = () => {
  return <div className="card-header">Nueva Evaluación</div>;
};

export default TituloNuevaEvaluacion;
