const Menu = () => {
  return (
    <header className="menu-header mb-4">
      <h2 className="menu-title">Bienvenido a Goalify</h2>
      
    </header>
  );
};

export default Menu;
